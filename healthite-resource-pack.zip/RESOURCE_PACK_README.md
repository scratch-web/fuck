# Healthite resource pack

This pack uses vanilla texture slots so the plugin can remain Geyser-friendly without custom Java item/block IDs.

## Slots

| Purpose | Vanilla slot | Pack texture |
|---|---|---|
| Raw Healthite | Ochre Froglight | `assets/minecraft/textures/block/ochre_froglight.png` |
| Refined Healthite | Verdant Froglight | `assets/minecraft/textures/block/verdant_froglight.png` |
| Healthite ore | Pearlescent Froglight | `assets/minecraft/textures/block/pearlescent_froglight.png` |
| Armor Gem | Prismarine Crystals | `assets/minecraft/textures/item/prismarine_crystals.png` |
| Heart Gem | Echo Shard | `assets/minecraft/textures/item/echo_shard.png` |

The item texture paths are also included for the froglight slots because different resource-pack model setups can reference item textures directly.

### Global replacement warning

These are vanilla texture slots. Therefore every ordinary Ochre Froglight, Verdant Froglight, Pearlescent Froglight, Prismarine Crystal, and Echo Shard will visually use the replacement texture while this pack is enabled.

The plugin's persistent tags still keep ordinary vanilla materials out of Healthite recipes.

### Geyser

Because all five slots are vanilla Minecraft materials, Bedrock clients already understand their identities. The plugin does not require Rainbow or Thunder just to identify these items.
